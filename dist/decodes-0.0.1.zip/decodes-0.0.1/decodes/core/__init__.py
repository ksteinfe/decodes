print "decodes core loaded"

VERBOSE_FS = True # determines if we verify file system loaded right
VERBOSE = True

from color import *

from base import *
from vec import *
from point import *
from cs import *

from line import *

from mesh import *
from pgon import *

from xform import *
from intersection import *
