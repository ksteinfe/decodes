===========
Decodes
===========

a platform agnostic generative design library for 3d designers